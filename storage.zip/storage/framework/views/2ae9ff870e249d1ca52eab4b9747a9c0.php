
<?php $__env->startSection('page-title', 'Edit Tentang Kami'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl space-y-6">
    <div>
        <h2 class="text-2xl font-bold text-admin-text">Edit Halaman Tentang Kami</h2>
        <p class="text-sm text-admin-muted mt-1">Konten ini akan tampil di halaman "Tentang Kami" pada situs publik.</p>
    </div>

    <?php if(session('success')): ?>
        <div class="p-3 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-sm font-medium">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" class="space-y-6">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <!-- Sejarah -->
        <div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm">
            <h3 class="text-base font-bold text-admin-text mb-4 flex items-center gap-2">
                <span class="w-1.5 h-5 bg-admin-accent rounded-full"></span>
                Sejarah / Profil Singkat Lembaga
            </h3>
            <textarea name="tentang_sejarah" rows="5" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="Contoh: LPK Karier Sukses berdiri sejak tahun ... dengan tujuan ..."><?php echo e(old('tentang_sejarah', $settings['tentang_sejarah'] ?? '')); ?></textarea>
            <?php $__errorArgs = ['tentang_sejarah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Visi Misi -->
        <div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm">
            <h3 class="text-base font-bold text-admin-text mb-4 flex items-center gap-2">
                <span class="w-1.5 h-5 bg-admin-accent rounded-full"></span>
                Visi & Misi
            </h3>
            <div class="mb-4">
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Visi</label>
                <textarea name="tentang_visi" rows="3" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none"><?php echo e(old('tentang_visi', $settings['tentang_visi'] ?? '')); ?></textarea>
                <?php $__errorArgs = ['tentang_visi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Misi</label>
                <textarea name="tentang_misi" rows="3" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none"><?php echo e(old('tentang_misi', $settings['tentang_misi'] ?? '')); ?></textarea>
                <?php $__errorArgs = ['tentang_misi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Keunggulan -->
        <div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm">
            <h3 class="text-base font-bold text-admin-text mb-2 flex items-center gap-2">
                <span class="w-1.5 h-5 bg-admin-accent rounded-full"></span>
                Keunggulan Kami
            </h3>
            <p class="text-xs text-admin-muted mb-4">Tulis satu poin keunggulan per baris (tekan Enter untuk poin baru). Setiap baris akan otomatis tampil sebagai daftar terpisah di halaman publik.</p>
            <textarea name="tentang_keunggulan" rows="5" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="Instruktur berpengalaman di bidangnya&#10;Jaminan penyaluran kerja bagi lulusan&#10;Sertifikat resmi setelah lulus&#10;Kelas kecil, belajar lebih fokus"><?php echo e(old('tentang_keunggulan', $settings['tentang_keunggulan'] ?? '')); ?></textarea>
            <?php $__errorArgs = ['tentang_keunggulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Kontak & Lokasi -->
        <div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm">
            <h3 class="text-base font-bold text-admin-text mb-4 flex items-center gap-2">
                <span class="w-1.5 h-5 bg-admin-accent rounded-full"></span>
                Kontak & Lokasi
            </h3>

            <div class="mb-4">
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Alamat</label>
                <textarea name="tentang_alamat" rows="2" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="Jl. Contoh No. 123, Kota, Provinsi"><?php echo e(old('tentang_alamat', $settings['tentang_alamat'] ?? '')); ?></textarea>
                <?php $__errorArgs = ['tentang_alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-semibold text-admin-text mb-1.5">Telepon / WhatsApp</label>
                    <input type="text" name="tentang_telepon" value="<?php echo e(old('tentang_telepon', $settings['tentang_telepon'] ?? '')); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="0812xxxxxxx">
                    <?php $__errorArgs = ['tentang_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-admin-text mb-1.5">Email</label>
                    <input type="email" name="tentang_email" value="<?php echo e(old('tentang_email', $settings['tentang_email'] ?? '')); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="info@lpkkariersukses.id">
                    <?php $__errorArgs = ['tentang_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Jam Operasional</label>
                <input type="text" name="tentang_jam_operasional" value="<?php echo e(old('tentang_jam_operasional', $settings['tentang_jam_operasional'] ?? '')); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="Senin - Jumat, 08.00 - 17.00 WIB">
                <?php $__errorArgs = ['tentang_jam_operasional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <button class="bg-admin-accent text-white px-8 py-3 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition">Simpan Semua Perubahan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>