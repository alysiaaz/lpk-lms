
<?php $__env->startSection('page-title', 'Tambah Modul'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-xl space-y-4">
    <a href="<?php echo e(route('admin.kursus.modul.index', $kursus->id)); ?>" class="text-sm text-admin-accent font-medium hover:underline">&larr; Kembali ke Silabus</a>

    <div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm">
        <h2 class="text-xl font-bold text-admin-text mb-1">Tambah Modul Baru</h2>
        <p class="text-sm text-admin-muted mb-6">Untuk kursus: <span class="font-semibold text-admin-text"><?php echo e($kursus->judul); ?></span></p>

        <form action="<?php echo e(route('admin.kursus.modul.store', $kursus->id)); ?>" method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>

            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Judul Modul</label>
                <input type="text" name="judul_modul" value="<?php echo e(old('judul_modul')); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="Contoh: Pengenalan HTML & CSS">
                <?php $__errorArgs = ['judul_modul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Urutan</label>
                <input type="number" name="urutan" min="1" value="<?php echo e(old('urutan', $urutanBerikutnya)); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none">
                <p class="text-xs text-admin-muted mt-1">Menentukan posisi modul ini dalam daftar silabus (1 = paling atas).</p>
                <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class="bg-admin-accent text-white px-6 py-2.5 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition">Simpan Modul</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/modul/create.blade.php ENDPATH**/ ?>