
<?php $__env->startSection('title', 'Katalog Program Pelatihan - LPK Karier Sukses'); ?>

<?php $__env->startSection('content'); ?>
    <!-- BANNER KATALOG -->
    <section class="bg-lpk-teal text-lpk-bg py-16 border-b border-lpk-teal/20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
            <span class="text-lpk-gold text-xs font-extrabold tracking-widest uppercase bg-lpk-charcoal/30 px-3.5 py-1.5 rounded-full border border-lpk-gold/30">Katalog Resmi 2026</span>
            <h1 class="text-3xl sm:text-5xl font-extrabold tracking-tight">Temukan Program Pelatihanmu</h1>
            <p class="text-lpk-bg/80 text-sm max-w-xl mx-auto font-normal">Kuasai skill baru yang paling dicari oleh industri saat ini, diajar langsung oleh praktisi berpengalaman.</p>

            <!-- FORM PENCARIAN & FILTER DI BANNER -->
        </div>
    </section>

    <!-- GRID HASIL KATALOG -->
    <section class="py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">


            <!-- Filter Bar -->
            <div class="bg-white rounded-2xl shadow-sm border border-lpk-teal/10 p-6 mb-8">
                <form method="GET" action="<?php echo e(route('kursus.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <!-- Search input -->
                    <div>
                        <label class="block text-sm font-bold text-lpk-teal mb-2">Cari Kursus</label>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                            placeholder="Cari judul atau deskripsi..." 
                            class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-lpk-teal focus:border-lpk-teal transition-colors">
                    </div>

                    <!-- Category filter -->
                    <div>
                        <label class="block text-sm font-bold text-lpk-teal mb-2">Kategori</label>
                        <select name="kategori_id" class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-lpk-teal focus:border-lpk-teal transition-colors">
                            <option value="">Semua Kategori</option>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kategori->id); ?>" 
                                        <?php echo e(request('kategori_id') == $kategori->id ? 'selected' : ''); ?>>
                                    <?php echo e($kategori->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Sort -->
                    <div>
                        <label class="block text-sm font-bold text-lpk-teal mb-2">Urutkan</label>
                        <select name="sort" class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-lpk-teal focus:border-lpk-teal transition-colors">
                            <option value="terbaru" <?php echo e(request('sort') == 'terbaru' ? 'selected' : ''); ?>>Terbaru</option>
                            <option value="terlama" <?php echo e(request('sort') == 'terlama' ? 'selected' : ''); ?>>Terlama</option>
                            <option value="paling-diminati" <?php echo e(request('sort') == 'paling-diminati' ? 'selected' : ''); ?>>Paling Diminati</option>
                            <option value="harga-murah" <?php echo e(request('sort') == 'harga-murah' ? 'selected' : ''); ?>>Harga Murah</option>
                            <option value="harga-mahal" <?php echo e(request('sort') == 'harga-mahal' ? 'selected' : ''); ?>>Harga Mahal</option>
                        </select>
                    </div>

                    <!-- Submit button -->
                    <div class="flex items-end gap-2">
                        <button type="submit" class="w-full bg-lpk-teal hover:bg-opacity-90 text-white font-bold py-2 px-4 rounded-xl transition">
                            Cari
                        </button>
                        <a href="<?php echo e(route('kursus.index')); ?>" class="w-full bg-lpk-mint hover:bg-lpk-teal hover:text-white text-lpk-teal font-bold py-2 px-4 rounded-xl text-center transition">
                            Reset
                        </a>
                    </div>
                </form>
            </div>

            <!-- Results count -->
            <div class="mb-6">
                <p class="text-gray-600">
                    Menampilkan <strong><?php echo e($semuaKursus->count()); ?></strong> dari 
                    <strong><?php echo e($semuaKursus->total()); ?></strong> kursus
                    <?php if(request('search')): ?>
                        dengan pencarian: <strong>"<?php echo e(request('search')); ?>"</strong>
                    <?php endif; ?>
                </p>
            </div>

            <!-- Kursus Grid (HANYA 1 GRID) -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <?php $__empty_1 = true; $__currentLoopData = $semuaKursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kursus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginalacade01c3e5ec38cb25f116a458bd17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalacade01c3e5ec38cb25f116a458bd17f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kartu-kursus','data' => ['kursus' => $kursus]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kartu-kursus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['kursus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kursus)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalacade01c3e5ec38cb25f116a458bd17f)): ?>
<?php $attributes = $__attributesOriginalacade01c3e5ec38cb25f116a458bd17f; ?>
<?php unset($__attributesOriginalacade01c3e5ec38cb25f116a458bd17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalacade01c3e5ec38cb25f116a458bd17f)): ?>
<?php $component = $__componentOriginalacade01c3e5ec38cb25f116a458bd17f; ?>
<?php unset($__componentOriginalacade01c3e5ec38cb25f116a458bd17f); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center py-12">
                        <div class="text-4xl mb-3">🔍</div>
                        <p class="text-gray-500 text-lg font-bold">Tidak ada kursus yang sesuai</p>
                        <p class="text-gray-400 text-sm mb-4">Maaf, kursus yang kamu cari belum tersedia atau kata kuncinya kurang tepat.</p>
                        <a href="<?php echo e(route('kursus.index')); ?>" class="text-blue-600 hover:underline mt-2 inline-block font-semibold">
                            Kembali ke katalog lengkap
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <div class="mb-12">
                <?php echo e($semuaKursus->appends(request()->query())->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/publik/katalog.blade.php ENDPATH**/ ?>