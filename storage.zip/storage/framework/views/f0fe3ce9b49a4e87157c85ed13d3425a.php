<?php
    $isAdmin = auth()->user()->role === 'admin';
    $labelClass = $isAdmin ? 'block text-sm font-semibold text-admin-text mb-1.5' : 'block text-xs font-bold text-lpk-charcoal mb-1';
    $inputClass = $isAdmin
        ? 'w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none'
        : 'w-full px-4 py-3 bg-lpk-bg text-lpk-charcoal text-sm font-medium rounded-2xl border border-lpk-teal/20 focus:outline-none focus:border-lpk-teal';
    $buttonClass = $isAdmin
        ? 'bg-admin-accent text-white px-6 py-2.5 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition'
        : 'bg-lpk-teal hover:bg-lpk-charcoal text-lpk-bg font-extrabold px-6 py-3 rounded-2xl text-sm transition-all shadow-md';
    $ghostButtonClass = $isAdmin
        ? 'bg-admin-bg text-admin-muted px-4 py-2 rounded-lg font-semibold text-xs hover:bg-red-50 hover:text-red-600 transition'
        : 'bg-lpk-bg text-lpk-charcoal/70 px-4 py-2 rounded-xl font-bold text-xs hover:bg-red-50 hover:text-red-600 transition border border-lpk-teal/10';
    $headingClass = $isAdmin ? 'text-lg font-bold text-admin-text' : 'text-lg font-extrabold text-lpk-teal';
    $subClass = $isAdmin ? 'mt-1 text-sm text-admin-muted' : 'mt-1 text-xs text-lpk-charcoal/70 font-medium';
    $errorClass = 'text-red-600 text-xs mt-1 font-semibold';
    $ringClass = $isAdmin ? 'ring-admin-border' : 'ring-lpk-teal/15';
?>

<section>
    <header>
        <h2 class="<?php echo e($headingClass); ?>"><?php echo e(__('Informasi Profil')); ?></h2>
        <p class="<?php echo e($subClass); ?>"><?php echo e(__('Perbarui foto, nama, dan alamat email akunmu.')); ?></p>
    </header>

    <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
    </form>

    <form method="post" action="<?php echo e(route('profile.update')); ?>" class="mt-6 space-y-5" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>

        <!-- Foto Profil -->
        <div class="flex items-center gap-5">
            <img src="<?php echo e($user->avatarUrl()); ?>" alt="Foto profil <?php echo e($user->name); ?>"
                 class="w-16 h-16 rounded-full object-cover ring-2 <?php echo e($ringClass); ?>"
                 id="avatar-preview">

            <div class="space-y-2">
                <label class="<?php echo e($ghostButtonClass); ?> inline-block cursor-pointer">
                    Ganti Foto
                    <input type="file" name="avatar" id="avatar-input" accept="image/*" class="hidden">
                </label>
                <p id="avatar-filename" class="text-[11px] <?php echo e($isAdmin ? 'text-admin-muted' : 'text-lpk-charcoal/50'); ?>"></p>
                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-[11px] <?php echo e($isAdmin ? 'text-admin-muted' : 'text-lpk-charcoal/50'); ?>">JPG/PNG, maks 2MB.</p>
            </div>
        </div>

        <script>
            (function () {
                var input = document.getElementById('avatar-input');
                var preview = document.getElementById('avatar-preview');
                var filenameLabel = document.getElementById('avatar-filename');
                if (!input || !preview) return;

                input.addEventListener('change', function () {
                    if (!this.files || !this.files[0]) return;
                    var file = this.files[0];
                    preview.src = URL.createObjectURL(file);
                    if (filenameLabel) filenameLabel.textContent = file.name;
                });
            })();
        </script>

        <div>
            <label for="name" class="<?php echo e($labelClass); ?>">Nama</label>
            <input id="name" name="name" type="text" class="<?php echo e($inputClass); ?>" value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="email" class="<?php echo e($labelClass); ?>">Email</label>
            <input id="email" name="email" type="email" class="<?php echo e($inputClass); ?>" value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                <div>
                    <p class="text-sm mt-2 <?php echo e($isAdmin ? 'text-admin-text' : 'text-lpk-charcoal'); ?>">
                        <?php echo e(__('Alamat email kamu belum diverifikasi.')); ?>

                        <button form="send-verification" class="underline text-sm font-semibold <?php echo e($isAdmin ? 'text-admin-accent hover:text-admin-accent-dark' : 'text-lpk-teal hover:text-lpk-gold'); ?>">
                            <?php echo e(__('Klik di sini untuk kirim ulang email verifikasi.')); ?>

                        </button>
                    </p>

                    <?php if(session('status') === 'verification-link-sent'): ?>
                        <p class="mt-2 font-semibold text-sm text-emerald-600">
                            <?php echo e(__('Link verifikasi baru telah dikirim ke email kamu.')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="flex items-center gap-4 pt-1">
            <button type="submit" class="<?php echo e($buttonClass); ?>"><?php echo e(__('Simpan')); ?></button>

            <?php if(session('status') === 'profile-updated'): ?>
                <p class="text-sm text-emerald-600 font-semibold"><?php echo e(__('Tersimpan.')); ?></p>
            <?php endif; ?>
            <?php if(session('status') === 'avatar-removed'): ?>
                <p class="text-sm text-emerald-600 font-semibold"><?php echo e(__('Foto profil dihapus.')); ?></p>
            <?php endif; ?>
        </div>
    </form>

    <?php if($user->avatar): ?>
        <form method="post" action="<?php echo e(route('profile.avatar.destroy')); ?>" class="mt-3" onsubmit="return confirm('Hapus foto profil? Akan diganti dengan avatar inisial.')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="text-xs font-bold text-red-500 hover:underline">Hapus foto profil</button>
        </form>
    <?php endif; ?>
</section>
<?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>