
<?php $__env->startSection('page-title', 'Data Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div>
        <h2 class="text-2xl font-bold text-admin-text">Data Pendaftaran Peserta</h2>
        <p class="text-sm text-admin-muted mt-1">Semua peserta yang mendaftar ke kursus.</p>
    </div>

    <?php if(session('success')): ?>
        <div class="p-3 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-sm font-medium"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl border border-admin-border shadow-sm overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-admin-bg">
                <tr class="text-admin-muted uppercase text-xs font-bold">
                    <th class="px-6 py-3.5">No</th>
                    <th class="px-6 py-3.5">Nama Peserta</th>
                    <th class="px-6 py-3.5">Email</th>
                    <th class="px-6 py-3.5">Kursus</th>
                    <th class="px-6 py-3.5">Status</th>
                    <th class="px-6 py-3.5">Tanggal Daftar</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-admin-border">
                <?php $__empty_1 = true; $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-admin-bg/60 transition">
                    <td class="px-6 py-4 text-sm text-admin-muted"><?php echo e($index + 1); ?></td>
                    <td class="px-6 py-4 font-semibold text-admin-text text-sm"><?php echo e($item->peserta->name); ?></td>
                    <td class="px-6 py-4 text-admin-muted text-sm"><?php echo e($item->peserta->email); ?></td>
                    <td class="px-6 py-4 text-sm"><?php echo e($item->kursus->judul); ?></td>
                    <td class="px-6 py-4">
                        <span class="text-xs font-bold px-3 py-1 rounded-full <?php echo e($item->status === 'aktif' ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-600'); ?>">
                            <?php echo e(ucfirst($item->status)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-admin-muted text-sm"><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d M Y, H:i')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-10 text-center text-admin-muted text-sm">Belum ada peserta yang mendaftar kursus.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/enrollments/index.blade.php ENDPATH**/ ?>