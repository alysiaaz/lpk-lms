
<?php $__env->startSection('title', 'Checkout - ' . $kursus->judul); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-6 py-12">
    <h1 class="text-2xl font-extrabold text-lpk-charcoal mb-8">Ringkasan Pesanan</h1>

    <?php if(session('success')): ?>
        <div class="p-4 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-sm font-medium mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <!-- Detail kursus -->
        <div class="md:col-span-2 bg-white rounded-2xl border border-lpk-mint shadow-sm p-6">
            <div class="flex gap-4">
                <img src="<?php echo e($kursus->thumbnail ? asset('storage/' . $kursus->thumbnail) : 'https://via.placeholder.com/120'); ?>"
                     alt="<?php echo e($kursus->judul); ?>" class="w-28 h-28 rounded-xl object-cover shrink-0">
                <div>
                    <h2 class="text-lg font-bold text-lpk-charcoal"><?php echo e($kursus->judul); ?></h2>
                    <p class="text-sm text-lpk-charcoal/60 mt-1"><?php echo e(Str::limit($kursus->deskripsi ?? '', 120)); ?></p>
                    <p class="text-lpk-gold font-bold mt-3">Rp <?php echo e(number_format($kursus->harga, 0, ',', '.')); ?></p>
                </div>
            </div>
        </div>

        <!-- Ringkasan & voucher -->
        <div class="bg-white rounded-2xl border border-lpk-mint shadow-sm p-6 h-fit">
            <h3 class="font-bold text-lpk-charcoal mb-4">Ringkasan</h3>

            <div class="space-y-2 text-sm">
                <div class="flex justify-between text-lpk-charcoal/70">
                    <span>Subtotal</span>
                    <span>Rp <?php echo e(number_format($kursus->harga, 0, ',', '.')); ?></span>
                </div>

                <?php if($voucher): ?>
                <div class="flex justify-between text-emerald-600">
                    <span>Diskon (<?php echo e($voucher->kode); ?>)</span>
                    <span>- Rp <?php echo e(number_format($diskon, 0, ',', '.')); ?></span>
                </div>
                <?php endif; ?>
            </div>

            <div class="border-t border-lpk-mint mt-4 pt-4 flex justify-between items-center">
                <span class="font-bold text-lpk-charcoal">Total Akhir</span>
                <span class="font-extrabold text-lpk-gold text-lg">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></span>
            </div>

            <!-- Form voucher -->
            <div class="mt-6">
                <p class="text-sm font-semibold text-lpk-charcoal mb-2">Punya voucher?</p>

                <?php if($voucher): ?>
                    <div class="flex items-center justify-between bg-lpk-mint/60 rounded-lg px-3 py-2">
                        <span class="text-sm font-semibold text-lpk-teal"><?php echo e($voucher->kode); ?> terpasang</span>
                        <form action="<?php echo e(route('checkout.voucher.remove')); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-xs text-red-600 font-semibold hover:underline">Hapus</button>
                        </form>
                    </div>
                <?php else: ?>
                    <form action="<?php echo e(route('checkout.voucher.apply')); ?>" method="POST" class="flex gap-2">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="kursus_id" value="<?php echo e($kursus->id); ?>">
                        <input type="text" name="kode" placeholder="cth. MENTOR20"
                               class="flex-1 border border-lpk-mint rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-lpk-teal">
                        <button type="submit" class="bg-lpk-teal text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-lpk-teal/90 transition">
                            Gunakan
                        </button>
                    </form>
                    <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if(session('voucher_error')): ?>
                        <p class="text-red-600 text-xs mt-1"><?php echo e(session('voucher_error')); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Checkout -->
            <form action="<?php echo e(route('checkout.store', $kursus)); ?>" method="POST" class="mt-6">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full bg-lpk-gold text-white font-bold py-3 rounded-lg hover:bg-lpk-gold/90 transition shadow-sm">
                    Checkout
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/checkout/show.blade.php ENDPATH**/ ?>