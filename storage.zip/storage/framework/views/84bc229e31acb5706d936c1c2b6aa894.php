
<?php $__env->startSection('title', 'Tambah Soal - ' . $ujian->judul); ?>
<?php $__env->startSection('page-title', 'Tambah Soal Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto space-y-6">

    <div class="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
        <a href="<?php echo e(route('admin.kursus.ujian.soal.index', [$kursus->id, $ujian->id])); ?>" class="text-xs font-bold text-admin-navy hover:underline">&larr; Batal & Kembali</a>
        <h1 class="text-2xl font-black text-admin-navy mt-1">Buat Pertanyaan Baru</h1>
        <p class="text-sm text-gray-500 font-medium">Untuk Ujian: <?php echo e($ujian->judul); ?></p>
    </div>

    <div class="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm">
        <form action="<?php echo e(route('admin.kursus.ujian.soal.store', [$kursus->id, $ujian->id])); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>

            <!-- Pertanyaan -->
            <div>
                <label class="block text-sm font-bold text-admin-navy mb-2">Teks Pertanyaan <span class="text-red-500">*</span></label>
                <textarea name="pertanyaan" rows="3" placeholder="Tuliskan pertanyaan ujian di sini..." class="w-full px-4 py-3 rounded-2xl border border-gray-300 focus:ring-2 focus:ring-admin-navy focus:border-admin-navy text-sm font-medium" required><?php echo e(old('pertanyaan')); ?></textarea>
                <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <hr class="border-gray-100">

            <!-- 4 Opsi Pilihan Ganda -->
            <div class="space-y-4">
                <label class="block text-sm font-bold text-admin-navy">Pilihan Ganda & Kunci Jawaban <span class="text-red-500">*</span></label>
                <p class="text-xs text-gray-400 -mt-3 mb-2">Pilih salah satu radio button di sebelah kiri sebagai penanda kunci jawaban yang benar.</p>

                <?php $__currentLoopData = ['A', 'B', 'C', 'D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-3 p-2 rounded-2xl border border-gray-200 focus-within:border-admin-navy focus-within:ring-1 focus-within:ring-admin-navy">
                        <div class="pl-3 flex items-center gap-2">
                            <!-- Radio button untuk menandai mana opsi yang benar (indeks 0, 1, 2, atau 3) -->
                            <input type="radio" name="jawaban_benar" value="<?php echo e($index); ?>" class="w-4 h-4 text-admin-navy focus:ring-admin-navy cursor-pointer" <?php echo e($index === 0 ? 'checked' : ''); ?> required title="Jadikan kunci jawaban">
                            <span class="font-black text-sm text-gray-400"><?php echo e($label); ?></span>
                        </div>
                        <input type="text" name="opsi[]" placeholder="Tulis pilihan jawaban <?php echo e($label); ?>..." class="w-full border-0 focus:ring-0 text-sm font-medium py-2 px-2" required>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['jawaban_benar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tombol Simpan -->
            <div class="pt-4 flex items-center justify-end gap-3 border-t border-gray-100">
                <a href="<?php echo e(route('admin.kursus.ujian.soal.index', [$kursus->id, $ujian->id])); ?>" class="px-6 py-3.5 rounded-full text-sm font-bold text-gray-500 hover:bg-gray-100 transition">
                    Batal
                </a>
                <button type="submit" class="bg-admin-navy hover:bg-admin-navy-2 text-white font-extrabold text-sm px-8 py-3.5 rounded-full shadow transition">
                    Simpan Soal & Pilihan
                </button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/soal/create.blade.php ENDPATH**/ ?>