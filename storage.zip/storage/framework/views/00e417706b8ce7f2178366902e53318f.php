
<?php $__env->startSection('page-title', 'Tambah Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm max-w-lg">
    <h2 class="text-xl font-bold text-admin-text mb-6">Tambah Kategori Baru</h2>

    <form action="<?php echo e(route('admin.kategori.store')); ?>" method="POST" class="space-y-6">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Nama Kategori</label>
            <input type="text" name="nama" value="<?php echo e(old('nama')); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" placeholder="Misal: Desain Grafis">
            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="bg-admin-accent text-white px-6 py-2.5 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/kategori/create.blade.php ENDPATH**/ ?>