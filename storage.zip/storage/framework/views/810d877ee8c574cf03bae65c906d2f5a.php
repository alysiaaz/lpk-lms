
<?php $__env->startSection('title', 'Ruang Belajar - LPK Karier Sukses'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-12 bg-lpk-bg min-h-screen">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <!-- HEADER DASBOR -->
        <div class="bg-lpk-teal text-lpk-bg p-8 sm:p-10 rounded-[2.5rem] shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
            <div class="absolute right-0 top-0 w-80 h-80 bg-lpk-gold/15 rounded-full blur-3xl pointer-events-none"></div>
            <div class="space-y-2 relative z-10">
                <span class="bg-lpk-gold text-lpk-charcoal font-extrabold text-xs px-3 py-1 rounded-full uppercase tracking-wider">Ruang Peserta</span>
                <h1 class="text-3xl sm:text-4xl font-extrabold tracking-tight">Halo, <?php echo e(auth()->user()->name); ?>! 👋</h1>
                <p class="text-lpk-bg/80 text-sm max-w-xl font-normal">Selamat datang di panel belajarmu. Pilih program pelatihan di bawah ini untuk memulai atau melanjutkan progres keahlianmu.</p>
            </div>
            <div class="relative z-10">
                <a href="<?php echo e(url('/kursus')); ?>" class="inline-block bg-lpk-gold hover:bg-opacity-90 text-lpk-charcoal font-extrabold px-6 py-3.5 rounded-2xl text-sm transition-all shadow-md transform hover:-translate-y-0.5">
                    + Ambil Kursus Baru
                </a>
            </div>
        </div>

        <!-- REKOMENDASI KURSUS -->
        <div class="space-y-6">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-extrabold text-lpk-teal tracking-tight">Rekomendasi Program Keahlian</h2>
                    <p class="text-xs text-lpk-charcoal/70 font-medium">Kursus dengan peluang penyaluran kerja tertinggi minggu ini.</p>
                </div>
                <a href="<?php echo e(url('/kursus')); ?>" class="text-xs font-bold text-lpk-teal hover:text-lpk-gold transition-colors">Lihat Katalog →</a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <?php $__currentLoopData = $rekomendasiKursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalacade01c3e5ec38cb25f116a458bd17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalacade01c3e5ec38cb25f116a458bd17f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kartu-kursus','data' => ['kursus' => $item]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kartu-kursus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['kursus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalacade01c3e5ec38cb25f116a458bd17f)): ?>
<?php $attributes = $__attributesOriginalacade01c3e5ec38cb25f116a458bd17f; ?>
<?php unset($__attributesOriginalacade01c3e5ec38cb25f116a458bd17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalacade01c3e5ec38cb25f116a458bd17f)): ?>
<?php $component = $__componentOriginalacade01c3e5ec38cb25f116a458bd17f; ?>
<?php unset($__componentOriginalacade01c3e5ec38cb25f116a458bd17f); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/peserta/dashboard.blade.php ENDPATH**/ ?>