
<?php $__env->startSection('title', 'Tentang Kami'); ?>

<?php
    $sejarah = \App\Models\Setting::where('key', 'tentang_sejarah')->value('value');
    $visi = \App\Models\Setting::where('key', 'tentang_visi')->value('value');
    $misi = \App\Models\Setting::where('key', 'tentang_misi')->value('value');
    $keunggulanRaw = \App\Models\Setting::where('key', 'tentang_keunggulan')->value('value');
    $keunggulanList = $keunggulanRaw ? array_filter(array_map('trim', explode("\n", $keunggulanRaw))) : [];
    $alamat = \App\Models\Setting::where('key', 'tentang_alamat')->value('value');
    $telepon = \App\Models\Setting::where('key', 'tentang_telepon')->value('value');
    $email = \App\Models\Setting::where('key', 'tentang_email')->value('value');
    $jamOperasional = \App\Models\Setting::where('key', 'tentang_jam_operasional')->value('value');
?>

<?php $__env->startSection('content'); ?>
<div class="py-16 bg-lpk-bg">
    <div class="max-w-4xl mx-auto px-6 space-y-12">
        <h1 class="text-4xl font-extrabold text-lpk-teal text-center">Tentang Kami</h1>

        <!-- SEJARAH -->
        <div class="bg-white p-8 rounded-3xl border shadow-sm">
            <h2 class="text-xl font-bold text-lpk-teal mb-4">Sejarah Kami</h2>
            <p class="text-sm text-lpk-charcoal/80 leading-relaxed">
                <?php echo e($sejarah ?? 'Profil lembaga belum diatur oleh admin.'); ?>

            </p>
        </div>

        <!-- VISI MISI -->
        <div class="grid md:grid-cols-2 gap-8">
            <div class="bg-white p-8 rounded-3xl border shadow-sm">
                <h2 class="text-xl font-bold text-lpk-teal mb-4">Visi Kami</h2>
                <p class="text-sm text-lpk-charcoal/80 leading-relaxed">
                    <?php echo e($visi ?? 'Visi belum diatur oleh admin.'); ?>

                </p>
            </div>
            <div class="bg-white p-8 rounded-3xl border shadow-sm">
                <h2 class="text-xl font-bold text-lpk-teal mb-4">Misi Kami</h2>
                <p class="text-sm text-lpk-charcoal/80 leading-relaxed">
                    <?php echo e($misi ?? 'Misi belum diatur oleh admin.'); ?>

                </p>
            </div>
        </div>

        <!-- KEUNGGULAN -->
        <?php if(count($keunggulanList) > 0): ?>
        <div class="bg-white p-8 rounded-3xl border shadow-sm">
            <h2 class="text-xl font-bold text-lpk-teal mb-6 text-center">Kenapa Memilih Kami?</h2>
            <div class="grid sm:grid-cols-2 gap-4">
                <?php $__currentLoopData = $keunggulanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-start gap-3 bg-lpk-mint/40 rounded-2xl p-4">
                    <span class="text-lpk-teal font-extrabold">✓</span>
                    <span class="text-sm text-lpk-charcoal/90"><?php echo e($poin); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- KONTAK & LOKASI -->
        <?php if($alamat || $telepon || $email || $jamOperasional): ?>
        <div class="bg-lpk-teal text-lpk-bg p-8 sm:p-10 rounded-3xl shadow-sm">
            <h2 class="text-xl font-bold mb-6">Kontak & Lokasi</h2>
            <div class="grid sm:grid-cols-2 gap-6 text-sm">
                <?php if($alamat): ?>
                <div>
                    <p class="font-bold uppercase text-xs tracking-wider text-lpk-gold mb-1">Alamat</p>
                    <p class="leading-relaxed"><?php echo e($alamat); ?></p>
                </div>
                <?php endif; ?>
                <?php if($jamOperasional): ?>
                <div>
                    <p class="font-bold uppercase text-xs tracking-wider text-lpk-gold mb-1">Jam Operasional</p>
                    <p class="leading-relaxed"><?php echo e($jamOperasional); ?></p>
                </div>
                <?php endif; ?>
                <?php if($telepon): ?>
                <div>
                    <p class="font-bold uppercase text-xs tracking-wider text-lpk-gold mb-1">Telepon / WhatsApp</p>
                    <p class="leading-relaxed"><?php echo e($telepon); ?></p>
                </div>
                <?php endif; ?>
                <?php if($email): ?>
                <div>
                    <p class="font-bold uppercase text-xs tracking-wider text-lpk-gold mb-1">Email</p>
                    <p class="leading-relaxed"><?php echo e($email); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/publik/tentang.blade.php ENDPATH**/ ?>