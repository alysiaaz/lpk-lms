<?php
    $isAdmin = auth()->user()->role === 'admin';
    $labelClass = $isAdmin ? 'block text-sm font-semibold text-admin-text mb-1.5' : 'block text-xs font-bold text-lpk-charcoal mb-1';
    $inputClass = $isAdmin
        ? 'w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-red-400 focus:border-red-400 outline-none'
        : 'w-full px-4 py-3 bg-lpk-bg text-lpk-charcoal text-sm font-medium rounded-2xl border border-red-200 focus:outline-none focus:border-red-400';
    $dangerButtonClass = $isAdmin
        ? 'bg-red-50 hover:bg-red-100 text-red-600 px-6 py-2.5 rounded-lg font-semibold text-sm transition'
        : 'bg-red-600 hover:bg-red-700 text-white font-extrabold px-6 py-3 rounded-2xl text-sm transition-all shadow-md';
    $headingClass = $isAdmin ? 'text-lg font-bold text-red-600' : 'text-lg font-extrabold text-red-600';
    $subClass = $isAdmin ? 'mt-1 text-sm text-admin-muted' : 'mt-1 text-xs text-lpk-charcoal/70 font-medium';
    $errorClass = 'text-red-600 text-xs mt-1 font-semibold';
?>

<section class="space-y-5">
    <header>
        <h2 class="<?php echo e($headingClass); ?>"><?php echo e(__('Hapus Akun')); ?></h2>
        <p class="<?php echo e($subClass); ?>"><?php echo e(__('Setelah akun dihapus, semua data terkait akan hilang secara permanen. Unduh data yang ingin kamu simpan sebelum melanjutkan.')); ?></p>
    </header>

    <form method="post" action="<?php echo e(route('profile.destroy')); ?>" class="space-y-4" onsubmit="return confirm('Yakin ingin menghapus akun ini? Tindakan ini tidak bisa dibatalkan.')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>

        <div class="max-w-sm">
            <label for="password" class="<?php echo e($labelClass); ?>">Masukkan password untuk konfirmasi</label>
            <input id="password" name="password" type="password" class="<?php echo e($inputClass); ?>" placeholder="Password">
            <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="<?php echo e($dangerButtonClass); ?>"><?php echo e(__('Hapus Akun Saya')); ?></button>
    </form>
</section>
<?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>