<div class="bg-white rounded-2xl border border-admin-border shadow-sm p-6 space-y-5">
    <div>
        <label class="block text-sm font-semibold text-admin-text mb-1.5">Kode Voucher</label>
        <input type="text" name="kode" value="<?php echo e(old('kode', $voucher?->kode ?? '')); ?>"
            class="w-full border border-admin-border rounded-lg px-4 py-2.5 text-sm text-admin-text focus:outline-none focus:ring-2 focus:ring-admin-accent"
            placeholder="cth. MENTOR20" required>
        <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Tipe Diskon</label>
            <select name="tipe" class="w-full border border-admin-border rounded-lg px-4 py-2.5 text-sm text-admin-text focus:outline-none focus:ring-2 focus:ring-admin-accent" required>
                <option value="persen" <?php echo e(old('tipe', $voucher?->tipe ?? '') === 'persen' ? 'selected' : ''); ?>>Persen (%)</option>
                <option value="nominal" <?php echo e(old('tipe', $voucher?->tipe ?? '') === 'nominal' ? 'selected' : ''); ?>>Nominal (Rp)</option>
            </select>
            <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Nilai</label>
            <input type="number" name="nilai" value="<?php echo e(old('nilai', $voucher?->nilai ?? '')); ?>"
                class="w-full border border-admin-border rounded-lg px-4 py-2.5 text-sm text-admin-text focus:outline-none focus:ring-2 focus:ring-admin-accent" required>
            <?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Kuota</label>
            <input type="number" name="kuota" value="<?php echo e(old('kuota', $voucher?->kuota ?? '')); ?>"
                class="w-full border border-admin-border rounded-lg px-4 py-2.5 text-sm text-admin-text focus:outline-none focus:ring-2 focus:ring-admin-accent"
                placeholder="Kosongkan jika tak terbatas">
            <?php $__errorArgs = ['kuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Minimal Pembelian</label>
            <input type="number" name="min_pembelian" value="<?php echo e(old('min_pembelian', $voucher?->min_pembelian ?? 0)); ?>"
                class="w-full border border-admin-border rounded-lg px-4 py-2.5 text-sm text-admin-text focus:outline-none focus:ring-2 focus:ring-admin-accent">
            <?php $__errorArgs = ['min_pembelian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div>
        <label class="block text-sm font-semibold text-admin-text mb-1.5">Berlaku Sampai</label>
        <input type="date" name="berlaku_sampai" value="<?php echo e(old('berlaku_sampai', $voucher?->berlaku_sampai?->format('Y-m-d') ?? '')); ?>"
            class="w-full border border-admin-border rounded-lg px-4 py-2.5 text-sm text-admin-text focus:outline-none focus:ring-2 focus:ring-admin-accent">
        <?php $__errorArgs = ['berlaku_sampai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <label class="inline-flex items-center gap-2 cursor-pointer">
        <input type="checkbox" name="aktif" value="1" <?php echo e(old('aktif', $voucher?->aktif ?? true) ? 'checked' : ''); ?>

            class="w-4 h-4 rounded border-admin-border text-admin-accent focus:ring-admin-accent">
        <span class="text-sm font-medium text-admin-text">Aktifkan voucher</span>
    </label>
</div><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/vouchers/_form.blade.php ENDPATH**/ ?>