
<?php $__env->startSection('title', 'Edit Ujian - ' . $ujian->judul); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto space-y-6">

    <!-- Header -->
    <div class="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
        <a href="<?php echo e(route('admin.kursus.ujian.index', $kursus->id)); ?>" class="text-xs font-bold text-admin-accent hover:underline">&larr; Batal & Kembali</a>
        <h1 class="text-2xl font-black text-admin-navy mt-1">Edit Data Ujian</h1>
        <p class="text-sm text-gray-500 font-medium">Untuk kursus: <?php echo e($kursus->judul); ?></p>
    </div>

    <!-- Form -->
    <div class="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm">
        <form action="<?php echo e(route('admin.kursus.ujian.update', [$kursus->id, $ujian->id])); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Judul Ujian -->
            <div>
                <label class="block text-sm font-bold text-admin-navy mb-2">Judul Ujian <span class="text-red-500">*</span></label>
                <input type="text" name="judul" value="<?php echo e(old('judul', $ujian->judul)); ?>" class="w-full px-4 py-3 rounded-2xl border border-gray-300 focus:ring-2 focus:ring-admin-navy focus:border-admin-navy text-sm font-medium" required>
                <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <!-- Tipe Ujian -->
                <div>
                    <label class="block text-sm font-bold text-admin-navy mb-2">Tipe Ujian <span class="text-red-500">*</span></label>
                    <select name="tipe" class="w-full px-4 py-3 rounded-2xl border border-gray-300 focus:ring-2 focus:ring-admin-navy focus:border-admin-navy text-sm font-semibold" required>
                        <option value="pre-test" <?php echo e(old('tipe', $ujian->tipe) === 'pre-test' ? 'selected' : ''); ?>>📝 Pre-Test (Tahap Awal)</option>
                        <option value="post-test" <?php echo e(old('tipe', $ujian->tipe) === 'post-test' ? 'selected' : ''); ?>>🎓 Post-Test (Tahap Akhir)</option>
                    </select>
                    <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Durasi Waktu -->
                <div>
                    <label class="block text-sm font-bold text-admin-navy mb-2">Durasi Pengerjaan (Menit) <span class="text-red-500">*</span></label>
                    <input type="number" name="waktu_menit" value="<?php echo e(old('waktu_menit', $ujian->waktu_menit)); ?>" min="1" class="w-full px-4 py-3 rounded-2xl border border-gray-300 focus:ring-2 focus:ring-admin-navy focus:border-admin-navy text-sm font-bold" required>
                    <?php $__errorArgs = ['waktu_menit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Deskripsi -->
            <div>
                <label class="block text-sm font-bold text-admin-navy mb-2">Deskripsi atau Petunjuk Mengerjakan</label>
                <textarea name="deskripsi" rows="4" class="w-full px-4 py-3 rounded-2xl border border-gray-300 focus:ring-2 focus:ring-admin-navy focus:border-admin-navy text-sm font-medium"><?php echo e(old('deskripsi', $ujian->deskripsi)); ?></textarea>
                <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tombol Simpan -->
            <div class="pt-4 flex items-center justify-end gap-3 border-t border-gray-100">
                <a href="<?php echo e(route('admin.kursus.ujian.index', $kursus->id)); ?>" class="px-6 py-3.5 rounded-full text-sm font-bold text-gray-500 hover:bg-gray-100 transition">
                    Batal
                </a>
                <button type="submit" class="bg-admin-navy hover:bg-admin-navy-2 text-white font-extrabold text-sm px-8 py-3.5 rounded-full shadow transition">
                    Perbarui Ujian
                </button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/ujian/edit.blade.php ENDPATH**/ ?>