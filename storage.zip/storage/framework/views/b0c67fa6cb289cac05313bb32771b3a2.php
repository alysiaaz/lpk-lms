
<?php $__env->startSection('page-title', 'Edit Kursus'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-8 rounded-2xl border border-admin-border shadow-sm max-w-2xl">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-xl font-bold text-admin-text mb-1">Edit Kursus: <?php echo e($kursus->judul); ?></h2>
            <p class="text-sm text-admin-muted">Perbarui informasi dan spesifikasi kursus ini.</p>
        </div>
        <a href="<?php echo e(route('admin.kursus.index')); ?>" class="text-xs font-bold text-admin-accent hover:underline">&larr; Kembali</a>
    </div>

    <form action="<?php echo e(route('admin.kursus.update', $kursus->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Judul Kursus</label>
            <input type="text" name="judul" value="<?php echo e(old('judul', $kursus->judul)); ?>" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none" required>
            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Kategori</label>
            <select name="kategori_id" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none">
                <option value="">-- Pilih Kategori --</option>
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kategori->id); ?>" <?php if(old('kategori_id', $kursus->kategori_id) == $kategori->id): echo 'selected'; endif; ?>>
                        <?php echo e($kategori->nama); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-xs text-admin-muted mt-2">Atau ketik nama kategori baru (kosongkan pilihan di atas):</p>
            <input type="text" name="kategori_baru" value="<?php echo e(old('kategori_baru')); ?>" placeholder="Nama kategori baru" class="w-full border border-admin-border p-2.5 rounded-lg mt-1 focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none">
            <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Deskripsi</label>
            <textarea name="deskripsi" rows="4" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none"><?php echo e(old('deskripsi', $kursus->deskripsi)); ?></textarea>
            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Harga (Rp)</label>
            <input type="number" name="harga" min="0" step="1000" value="<?php echo e(old('harga', $kursus->harga)); ?>" placeholder="0" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none">
            <p class="text-xs text-admin-muted mt-1">Isi 0 jika kursus ini gratis.</p>
            <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Spesifikasi Kursus (Dropdown Pilihan) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-admin-bg p-4 rounded-xl border border-admin-border">
            <!-- Status Kelas -->
            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Status Kelas</label>
                <select name="status_kelas" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none text-sm bg-white">
                    <?php $__currentLoopData = ['Pendaftaran Buka', 'Pendaftaran Tutup', 'Kelas Penuh', 'Sedang Berlangsung']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php if(old('status_kelas', $kursus->status_kelas) == $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['status_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Metode Belajar -->
            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Metode Belajar</label>
                <select name="metode_belajar" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none text-sm bg-white">
                    <?php $__currentLoopData = ['Mandiri (Self-Paced / Kapan Saja)', 'Webinar Live (Online)', 'Tatap Muka (Offline di Kelas)', 'Hybrid (Online & Offline)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($metode); ?>" <?php if(old('metode_belajar', $kursus->metode_belajar) == $metode): echo 'selected'; endif; ?>><?php echo e($metode); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Tingkat Kesiapan -->
            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Tingkat Kesiapan</label>
                <select name="tingkat_kesiapan" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none text-sm bg-white">
                    <?php $__currentLoopData = ['Pemula (Beginner)', 'Menengah (Intermediate)', 'Mahir (Advanced)', 'Semua Tingkat (All Levels)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tingkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tingkat); ?>" <?php if(old('tingkat_kesiapan', $kursus->tingkat_kesiapan) == $tingkat): echo 'selected'; endif; ?>><?php echo e($tingkat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Sertifikat -->
            <div>
                <label class="block text-sm font-semibold text-admin-text mb-1.5">Sertifikat</label>
                <select name="sertifikat" class="w-full border border-admin-border p-2.5 rounded-lg focus:ring-2 focus:ring-admin-accent focus:border-admin-accent outline-none text-sm bg-white">
                    <?php $__currentLoopData = ['Sertifikat Penyelesaian (Completion)', 'Sertifikat Kompetensi + Nilai', 'Tidak Ada Sertifikat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sertifikat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sertifikat); ?>" <?php if(old('sertifikat', $kursus->sertifikat) == $sertifikat): echo 'selected'; endif; ?>><?php echo e($sertifikat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div>
            <label class="block text-sm font-semibold text-admin-text mb-1.5">Thumbnail Saat Ini</label>
            <?php if($kursus->thumbnail): ?>
                <img src="<?php echo e(asset('storage/' . $kursus->thumbnail)); ?>" alt="Thumbnail" class="w-32 h-20 object-cover rounded-lg mb-2 border">
            <?php endif; ?>
            <input type="file" name="thumbnail" accept="image/*" class="w-full border border-admin-border p-2.5 rounded-lg text-sm">
            <p class="text-xs text-admin-muted mt-1">Kosongkan jika tidak ingin mengubah thumbnail.</p>
            <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex items-center gap-2 bg-admin-bg p-3 rounded-lg">
            <input type="checkbox" name="is_unggulan" id="is_unggulan" value="1" <?php if(old('is_unggulan', $kursus->is_unggulan) == 1): echo 'checked'; endif; ?> class="w-4 h-4 accent-admin-accent">
            <label for="is_unggulan" class="text-sm font-semibold text-admin-text">Tampilkan sebagai Unggulan di Beranda</label>
        </div>

        <div class="flex justify-end gap-3 pt-2">
            <a href="<?php echo e(route('admin.kursus.index')); ?>" class="px-5 py-2.5 rounded-lg font-semibold text-sm bg-gray-100 hover:bg-gray-200 text-admin-text transition">Batal</a>
            <button type="submit" class="bg-admin-accent text-white px-6 py-2.5 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition">Simpan Perubahan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/kursus/edit.blade.php ENDPATH**/ ?>