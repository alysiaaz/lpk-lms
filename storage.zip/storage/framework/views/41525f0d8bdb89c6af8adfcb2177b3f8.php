<header class="sticky top-0 z-50 bg-lpk-bg/90 backdrop-blur-md border-b border-lpk-teal/10 transition-all">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <!-- Logo -->
        <a href="<?php echo e(url('/')); ?>" class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-lpk-teal rounded-xl flex items-center justify-center font-extrabold text-lpk-bg text-xl shadow-md">
                L
            </div>
            <span class="text-xl font-extrabold tracking-tight text-lpk-teal">LPK <span class="font-normal text-lpk-charcoal">Karier Sukses</span></span>
        </a>

        <!-- Menu Navigasi -->
        <nav class="hidden md:flex items-center space-x-8 text-sm font-semibold text-lpk-charcoal/80">
            <a href="<?php echo e(url('/')); ?>" class="<?php echo e(request()->is('/') ? 'text-lpk-teal font-bold border-b-2 border-lpk-gold pb-1' : 'hover:text-lpk-teal transition-colors'); ?>">
                Beranda
            </a>
            <a href="<?php echo e(url('/kursus')); ?>" class="<?php echo e(request()->is('kursus*') ? 'text-lpk-teal font-bold border-b-2 border-lpk-gold pb-1' : 'hover:text-lpk-teal transition-colors'); ?>">
                Semua Kursus
            </a>
            <a href="<?php echo e(url('/tentang')); ?>" class="<?php echo e(request()->is('tentang*') ? 'text-lpk-teal font-bold border-b-2 border-lpk-gold pb-1' : 'hover:text-lpk-teal transition-colors'); ?>">
                Tentang Kami
            </a>

            
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role === 'peserta'): ?>
                    <a href="<?php echo e(route('peserta.kursus')); ?>" class="<?php echo e(request()->routeIs('peserta.kursus') ? 'text-lpk-teal font-bold border-b-2 border-lpk-gold pb-1' : 'hover:text-lpk-teal transition-colors'); ?>">
                        Kursus Saya
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </nav>

        <div class="flex items-center space-x-4">
            <?php if(auth()->guard()->guest()): ?>
                <!-- Jika Belum Login -->
                <a href="<?php echo e(route('login')); ?>" class="text-sm font-bold text-lpk-teal hover:opacity-80 transition-opacity px-3 py-2">
                    Masuk
                </a>
                <a href="<?php echo e(route('register')); ?>" class="bg-lpk-gold hover:bg-opacity-90 text-lpk-charcoal text-sm font-extrabold px-6 py-2.5 rounded-full shadow-sm transition-all transform hover:-translate-y-0.5">
                    Daftar Sekarang
                </a>
            <?php else: ?>
                <!-- Jika Sudah Login -->
                <a href="<?php echo e(route('profile.edit')); ?>" class="flex items-center gap-2 text-sm font-bold text-lpk-charcoal/80 hover:text-lpk-teal transition-colors px-2 py-2 <?php echo e(request()->routeIs('profile.edit') ? 'text-lpk-teal' : ''); ?>">
                    <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="Foto profil" class="w-7 h-7 rounded-full object-cover ring-2 ring-lpk-teal/10">
                    <span class="hidden sm:inline">Profil Saya</span>
                </a>
                <a href="<?php echo e(url('/dashboard')); ?>" class="bg-lpk-teal text-lpk-bg hover:bg-lpk-charcoal text-xs font-extrabold px-5 py-2.5 rounded-full shadow-sm transition-all flex items-center space-x-2">
                    <span> Dasbor Saya</span>
                </a>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-xs font-bold text-red-600 hover:underline px-2 py-2">
                        Keluar
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</header><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/partials/navbar.blade.php ENDPATH**/ ?>