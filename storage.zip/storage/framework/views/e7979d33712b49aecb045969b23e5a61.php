
<?php $__env->startSection('page-title', 'Materi Modul'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <div>
            <a href="<?php echo e(route('admin.kursus.modul.index', $kursus->id)); ?>" class="text-sm text-admin-accent font-medium hover:underline">&larr; Kembali ke Silabus</a>
            <h1 class="text-2xl font-bold text-admin-text mt-1">Materi: <?php echo e($modul->judul_modul); ?></h1>
            <p class="text-sm text-admin-muted">Kursus: <?php echo e($kursus->judul); ?></p>
        </div>
        <a href="<?php echo e(route('admin.kursus.modul.materi.create', [$kursus->id, $modul->id])); ?>" class="inline-flex items-center gap-2 bg-admin-accent text-white px-5 py-2.5 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition shadow-sm">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14M5 12h14"/></svg>
            Tambah Materi
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="p-3 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-sm font-medium"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl border border-admin-border shadow-sm overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-admin-bg text-admin-muted uppercase text-xs font-bold">
                <tr>
                    <th class="px-6 py-3.5">Urutan</th>
                    <th class="px-6 py-3.5">Judul Materi</th>
                    <th class="px-6 py-3.5">Tipe</th>
                    <th class="px-6 py-3.5">Konten</th>
                    <th class="px-6 py-3.5">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-admin-border">
                <?php $__empty_1 = true; $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-admin-bg/60 transition">
                    <td class="px-6 py-4 text-sm text-admin-muted"><?php echo e($materi->urutan); ?></td>
                    <td class="px-6 py-4 font-semibold text-admin-text text-sm"><?php echo e($materi->judul_materi); ?></td>
                    <td class="px-6 py-4 text-sm">
                        <span class="inline-block px-2.5 py-1 rounded-full text-xs font-bold uppercase
                            <?php echo e($materi->tipe === 'pdf' ? 'bg-sky-50 text-sky-700' : 'bg-amber-50 text-amber-700'); ?>">
                            <?php echo e($materi->tipe); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm">
                        <?php if($materi->file_path): ?>
                            <a href="<?php echo e($materi->fileUrl()); ?>" target="_blank" class="text-admin-accent hover:underline font-medium">File terupload</a>
                        <?php elseif($materi->url_video): ?>
                            <a href="<?php echo e($materi->url_video); ?>" target="_blank" class="text-admin-accent hover:underline font-medium">Link eksternal</a>
                        <?php else: ?>
                            <span class="text-admin-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 space-x-3">
                        <a href="<?php echo e(route('admin.kursus.modul.materi.edit', [$kursus->id, $modul->id, $materi->id])); ?>" class="text-admin-accent font-semibold hover:underline text-sm">
                            Edit
                        </a>
                        <form action="<?php echo e(route('admin.kursus.modul.materi.destroy', [$kursus->id, $modul->id, $materi->id])); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus materi <?php echo e($materi->judul_materi); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 font-semibold hover:underline text-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-6 py-10 text-center text-admin-muted text-sm">Belum ada materi untuk modul ini.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/materi/index.blade.php ENDPATH**/ ?>