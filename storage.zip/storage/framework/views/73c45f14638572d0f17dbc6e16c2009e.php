
<?php $__env->startSection('page-title', 'Tambah Voucher'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div>
        <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="text-sm text-admin-accent font-medium hover:underline">&larr; Kembali ke Voucher</a>
        <h1 class="text-2xl font-bold text-admin-text mt-1">Tambah Voucher</h1>
    </div>

    <form action="<?php echo e(route('admin.vouchers.store')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.vouchers._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="flex justify-end">
            <button type="submit" class="bg-admin-accent text-white px-6 py-2.5 rounded-lg font-semibold text-sm hover:bg-admin-accent-dark transition shadow-sm">
                Simpan Voucher
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/admin/vouchers/create.blade.php ENDPATH**/ ?>