<?php $isAdmin = auth()->user()->role === 'admin'; ?>

<?php $__env->startSection('title', 'Profil Saya - LPK Karier Sukses'); ?>
<?php $__env->startSection('page-title', 'Profil Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="<?php echo e($isAdmin ? '' : 'py-12 bg-lpk-bg min-h-screen px-4 sm:px-6 lg:px-8'); ?>">
<div class="max-w-3xl mx-auto space-y-6">

    <?php if (! ($isAdmin)): ?>
        <div class="space-y-1">
            <h1 class="text-3xl font-extrabold text-lpk-teal">Profil Saya</h1>
            <p class="text-sm text-lpk-charcoal/70">Kelola informasi akun dan keamanan login kamu.</p>
        </div>
    <?php endif; ?>

    <div class="<?php echo e($isAdmin ? 'bg-white p-6 sm:p-8 rounded-2xl border border-admin-border shadow-sm' : 'bg-white p-6 sm:p-8 rounded-3xl border border-lpk-teal/10 shadow-sm'); ?>">
        <div class="max-w-xl">
            <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="<?php echo e($isAdmin ? 'bg-white p-6 sm:p-8 rounded-2xl border border-admin-border shadow-sm' : 'bg-white p-6 sm:p-8 rounded-3xl border border-lpk-teal/10 shadow-sm'); ?>">
        <div class="max-w-xl">
            <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="<?php echo e($isAdmin ? 'bg-white p-6 sm:p-8 rounded-2xl border border-red-100 shadow-sm' : 'bg-white p-6 sm:p-8 rounded-3xl border border-red-100 shadow-sm'); ?>">
        <div class="max-w-xl">
            <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($isAdmin ? 'layouts.admin' : 'layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Belajar_Web\lpk-lms\resources\views/profile/edit.blade.php ENDPATH**/ ?>